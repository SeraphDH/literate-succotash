class Boggle {
  /* make a new game at this DOM id */

  constructor(boardId) {
    this.score = 0;
    //this.words = new Set();
    this.board = $("#" + boardId);

    this.timer = setInterval(this.time.bind(this), 1000);

    this.clock = 60;

    this.guesses = [];

    $(".add-word", this.board).on("submit", this.submit.bind(this));
  }

  /* show a status message */

  showMessage(msg) {
    $(".msg", this.board)
      .text(msg);
  }

  /* handle submission of word: if unique and valid, score & show */

  Score(){
    $('.score', this.board).text(this.score);
  }

  Clock(){
    $('.time', this.board).text(this.clock);
  }

  async submit(event) {
    event.preventDefault();
    const $word = $(".word", this.board);

    let word = $word.val();
    if (!word) return;


     //if (this.words.has(word)) {
    //  this.showMessage(`Already found ${word}`, "err");
    //  return;
    //}

    // check server for validity
    const result = await axios.get("/check-word", { params: { word: word }});
    if (result.data.result === "not-word") {
      this.showMessage(`${word} is not a valid English word`);
    } else if (result.data.result === "not-on-board") {
      this.showMessage(`${word} is not a valid word on this board`);
    } else {
      if (this.guesses.includes(word.toLowerCase()) == true){
        this.showMessage(`${word} has already been guessed, try again!`);
        return;
      }
      this.guesses.push(word.toLowerCase());
      this.showMessage(`Added: ${word}`);

      this.score += 0+(word.length);
      this.Score();
    }
    

    $word.val("").focus();
  }
 
  async time() {
    this.clock -= 1;
    this.Clock();

    if(this.clock == 0){
      clearInterval(this.timer);
      $('.add-word', this.board).hide();
      const gameover = await axios.post("/Gameover", { params: {score: this.score}});
      console.log(gameover.data);
      this.Highscore(gameover.data['highscore']);
      this.Playcount(gameover.data['playcount']); 

    }
  }

  Highscore(Highscore){
    console.log(Highscore);
    $('.highscore', this.board).text(Highscore);
    }

   Playcount(Playcount){
    $('.playcount', this.board).text(Playcount);
   }
  }
