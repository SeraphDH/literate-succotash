from unittest import TestCase
from app import app
from flask import session
from boggle import Boggle


class FlaskTests(TestCase):
    def setUp(self):
        self.testClient = app.test_client()
        app.config['TESTING'] = True
    def test_add(self):
        with self.testClient:
            result = self.testClient.get('/')
            self.assertIn('board', session)
            self.assertNotIn('playcount', session)
            self.assertNotIn('highscore', session)
            self.assertIn(b'Highscore:', result.data)
            self.assertIn(b'Playcount:', result.data)
            self.assertIn(b'Time Left', result.data)
            
    def test_add2(self):
        with self.testClient:
            board1 = []
            for y in range(5):
                row = ['B','O','A','R','D']
                board1.append(row)
            with self.testClient.session_transaction() as change_session:
                change_session['board'] = board1           
            
        result = self.testClient.get('/check-word?word=board')
        self.assertEquals('ok', result.json['result'])

    def test_add3(self):
        with self.testClient:
            board1 = []
            for y in range(5):
                row = ['B','O','A','R','D']
                board1.append(row)
            with self.testClient.session_transaction() as change_session:
                change_session['board'] = board1           
            
        result = self.testClient.get('/check-word?word=banana')
        self.assertEquals('not-on-board', result.json['result'])

    def test_add4(self):
        with self.testClient:
            board1 = []
            for y in range(5):
                row = ['B','O','A','R','D']
                board1.append(row)
            with self.testClient.session_transaction() as change_session:
                change_session['board'] = board1           
            
        result = self.testClient.get('/check-word?word=jfvsibvs')
        self.assertEquals('not-word', result.json['result'])

